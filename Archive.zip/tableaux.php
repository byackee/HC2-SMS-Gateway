<?php
$devices = array();
	$devices[chambre][lumiere] = 82;
	$devices[salon][lumiere] = 42;

$commandes = array();
	$commandes[0] = array('on','turnOn','allume');
	$commandes[1] = array('off','turnOff','eteint');
?>